package com.example.multimodel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultimodelApplicationTests {

	@Test
	void contextLoads() {
	}

}
