package com.example.prompttemplate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrompttemplateApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrompttemplateApplication.class, args);
	}

}
