package com.example.prompttemplate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrompttemplateApplicationTests {

	@Test
	void contextLoads() {
	}

}
